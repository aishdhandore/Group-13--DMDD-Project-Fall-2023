import streamlit as st
from PIL import Image

st.title('Movie Database Management System')
# st.write('')
st.image('movieimg.jfif')
