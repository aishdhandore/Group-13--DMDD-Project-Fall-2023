import pyodbc

#https://learn.microsoft.com/en-us/sql/connect/odbc/linux-mac/install-microsoft-odbc-driver-sql-server-macos?view=sql-server-ver16

conn = pyodbc.connect('DRIVER={ODBC Driver 18 for SQL Server};SERVER={127.0.0.1};DATABASE={MovieDatabase};Trusted_Connection=no;Encrypt=no;UID={sa};PWD={Password@123}')
print("before cursor")
cursor = conn.cursor()
print("After cursor")

quer = "SELECT * FROM Movie"
cursor.execute(quer)
rows = cursor.fetchall()
for row in rows:
    print(row)

cursor.close()
conn.close()
