import streamlit as st
import pandas as pd
import pyodbc

server = 'LAPTOP-9CQAHHJ1'
database = 'FinalProject'
driver = 'ODBC Driver 17 for SQL Server'
conn = pyodbc.connect('DRIVER={ODBC Driver 18 for SQL Server};SERVER={127.0.0.1};DATABASE={MovieDatabase};Trusted_Connection=no;Encrypt=no;UID={sa};PWD={Password@123}')
cursor = conn.cursor()


st.title('Movie Database Management System')
st.subheader('Review')


def add_review(userid,movieid,content,rating,reviewdate):
    try:
        cursor.execute("INSERT INTO Review (user_id,movie_id,content,rating,review_date) VALUES (?, ?, ?, ?, ?)",userid,movieid,content,rating,reviewdate)
        conn.commit()
        st.success("Review details successfully added!")
    except Exception as e:
        st.error(f"Error adding Review: {e}")


def read_review(movie_id):
    try:
        cursor.execute("SELECT * FROM Review WHERE movie_id = ?", movie_id)
        result = cursor.fetchall()

        if result:
            for row in result:
                df  = pd.DataFrame([list(row)], columns=['review_id','user_id','movie_id','content','rating','review_date'])
                st.table(df)
        else:
            st.warning("No Movies available")
    except Exception as e:
        st.error(f"Movie review reading : {e}")


def delete_review(reviewid):
    try:
        cursor.execute("DELETE FROM review WHERE review_id = ?", reviewid)
        conn.commit()
        st.success("Review deleted!")
    except Exception as e:
        st.error(f"Error deleting review: {e}")


option = st.radio('Select the operation', ["Add", "Read", "Delete",])
if option == "Add":
    userid = st.text_input("User ID:")
    movieid = st.text_input("Movie ID:")
    content = st.text_input("Review:")
    rating = st.number_input("Rating:")
    reviewdate = st.text_input("Review Date:")
    if st.button("Add Movie Review"):
        add_review(userid,movieid,content,rating,reviewdate)

elif option == "Read":
    movie_id = st.text_input("Enter Movie ID:")
    if st.button("View Movie Reviews"):
        read_review(movie_id)

elif option == "Delete":
    reviewid = st.text_input("Enter Review ID:")
    if st.button("Delete Movie Review"):
        delete_review(reviewid)