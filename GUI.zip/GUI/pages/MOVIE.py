import streamlit as st
import pandas as pd
import pyodbc

server = 'LAPTOP-9CQAHHJ1'
database = 'FinalProject'
driver = 'ODBC Driver 17 for SQL Server'
conn = pyodbc.connect('DRIVER={ODBC Driver 18 for SQL Server};SERVER={127.0.0.1};DATABASE={MovieDatabase};Trusted_Connection=no;Encrypt=no;UID={sa};PWD={Password@123}')
cursor = conn.cursor()


st.title('Movie Database Management System')
st.subheader('Movie')


def create_movie(companyid,title,release_year,duration,language,budget,revenue):
    try:
        cursor.execute("INSERT INTO Movie (company_id,title,release_year,duration,language,budget,revenue) VALUES (?, ?, ?, ?, ?,?,?)",companyid,title,release_year,duration,language,budget,revenue)
        conn.commit()
        st.success("Movie details successfully added!")
    except Exception as e:
        st.error(f"Error creating Movie: {e}")

def read_movie(movie_id):
    try:
        cursor.execute("SELECT * FROM Movie WHERE movie_id = ?", movie_id)
        result = cursor.fetchone()
        if result:
            df = pd.DataFrame([list(result)], columns=['movie_id','company_id','title','release_year','duration','language','budget','revenue'])
            st.table(df)
        else:
            st.warning("Movie not found.")
    except Exception as e:
        st.error(f"Movie reading : {e}")

def update_movie(movieid,companyid,title,release_year,duration,language,budget,revenue):
    try:
        cursor.execute("UPDATE Movie SET title = ?, release_year = ?, duration = ?, language = ?, budget = ?,revenue = ? WHERE movie_id = ?", title,release_year,duration,language,budget,revenue,movieid)
        conn.commit()
        st.success("Movie updated!")
    except Exception as e:
        st.error(f"Error updating Movie: {e}")

def delete_movie(movieid):
    try:
        cursor.execute("EXEC DeleteMovieAndRelatedRecords @MovieID=?", movieid)
        conn.commit()
        st.success("Movie deleted!")
    except Exception as e:
        st.error(f"Error deleting Movie: {e}")

def read_movies():
    try:
        cursor.execute("SELECT * FROM Movie")
        result = cursor.fetchall()
        # print(result)
        if result:
            for row in result:
                df  = pd.DataFrame([list(row)], columns=['movie_id','company_id','title','release_year','duration','language','budget','revenue'])
                st.table(df)
        else:
            st.warning("No Movies available")
    except Exception as e:
        st.error(f"Error reading Movie: {e}")

def top_movies(year,cnt):
    try:
        cursor.execute("EXEC GetTopRatedMoviesByYear @Year=?, @TopN=?", year, cnt)
        result = cursor.fetchall()
        # print(result)
        if result:
            for row in result:
                df  = pd.DataFrame([list(row)], columns=['movie_id','title','rating'])
                st.table(df)
        else:
            st.warning("No Movies available")
    except Exception as e:
        st.error(f"Error reading Movie: {e}")

option = st.radio('Select the operation', ["Create", "Read", "Update", "Delete", "Read All","Top Movies"])
if option == "Create":
    company_id = st.text_input("Production Company:")
    title = st.text_input("Movie Name:")
    release_year = st.text_input("Release Year:")
    duration = st.number_input("Movie Duration:")
    Language = st.text_input("Language:")
    budget = st.number_input("Budget:")
    revenue = st.number_input("Revenue:")
    if st.button("Create Movie"):
        create_movie(company_id, title, release_year, duration, Language,budget,revenue)

elif option == "Read":
    busid = st.number_input("Enter Movie ID:")
    if st.button("View Movie"):
        read_movie(busid)

elif option == "Update":
    title = st.text_input("Movie Name:")
    release_year = st.text_input("Release Year:")
    duration = st.number_input("Movie Duration:")
    Language = st.text_input("Language:")
    budget = st.number_input("Budget:")
    revenue = st.number_input("Revenue:")
    if st.button("Update Movie"):
        update_company(title, release_year, duration, Language,budget,revenue)

elif option == "Delete":
    movieid = st.number_input("Enter Movie ID:")
    if st.button("Delete Movie"):
        delete_movie(movieid)

elif option == "Read All":
    if st.button("View Movies"):
        read_movies()

elif option == "Top Movies":
    release_year = st.text_input("Release Year:")
    if st.button("View Top Movies By Year"):
        top_movies(release_year,5)