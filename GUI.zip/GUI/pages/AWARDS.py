import streamlit as st
import pandas as pd
import pyodbc

#
# server = 'LAPTOP-9CQAHHJ1'
# database = 'FinalProject'
# driver = 'ODBC Driver 17 for SQL Server'
conn = pyodbc.connect('DRIVER={ODBC Driver 18 for SQL Server};SERVER={127.0.0.1};DATABASE={MovieDatabase};'
                      'Trusted_Connection=no;Encrypt=no;UID={sa};PWD={Password@123}')
cursor = conn.cursor()

st.title('Movie Database Management System')
st.subheader('Awards')


# Define CRUD functions
def create_Awards(award_name, award_year, category):
    insert_query = cursor.execute("INSERT INTO Awards (award_name, award_year, category)"
                                  "VALUES ( ?, ?, ?)", award_name, award_year, category)
    conn.commit()
    st.success("Awards details successfully added!")


def view_Awards(award_id):
    cursor.execute("SELECT * FROM Awards WHERE award_id = ?", award_id)
    result = cursor.fetchone()
    if result:
        df = pd.DataFrame([list(result)], columns=['award_id', 'award_name', 'award_year', 'category'])
        st.table(df)
    else:
        st.warning("Award details not found.")


def update_Awards(oaward_name,naward_name, award_year, category):
    cursor.execute("UPDATE Awards SET award_name =?, award_year =?, category =? WHERE award_name =?", naward_name, award_year, category,oaward_name)
    conn.commit()
    st.success("Award Details updated successfully!")


def delete_Awards(award_id):
    cursor.execute("DELETE FROM Awards WHERE award_id = ?", award_id)
    conn.commit()
    st.warning("Award Details details deleted successfully")


option = st.radio('Select the operation', ["Create", "Read", "Update"])

if option == "Create":
    # bus_id = st.number_input("Bus ID:")
    award_name = st.text_input("Award Name:")
    award_year = st.text_input("Award Year:")
    category = st.text_input("Category:")

    if st.button("Add Awards"):
        create_Awards( award_name, award_year, category)

elif option == "Read":
    award_id = st.text_input("Enter Award ID:")
    if st.button("View"):
        view_Awards(award_id)


elif option == "Update":
    oaward_name = st.text_input("Current Award Name:")
    naward_name = st.text_input("Updated Award Name:")
    award_year = st.text_input("Award Year:")
    category = st.text_input("Category:")
    if st.button("Update"):
        update_Awards( oaward_name,naward_name, award_year, category)

if 0:
    option == "Delete"
    award_id = st.number_input("Enter Company ID:")
    if st.button("Delete"):
        delete_Awards(award_id)
