import streamlit as st
import pandas as pd
import pyodbc

server = 'LAPTOP-9CQAHHJ1'
database = 'FinalProject'
driver = 'ODBC Driver 17 for SQL Server'
conn = pyodbc.connect('DRIVER={ODBC Driver 18 for SQL Server};SERVER={127.0.0.1};DATABASE={MovieDatabase};Trusted_Connection=no;Encrypt=no;UID={sa};PWD={Password@123}')
cursor = conn.cursor()


st.title('Movie Database Management System')
st.subheader('USERS')


def create_user(username,password,email,registration_date):
    try:
        cursor.execute("INSERT INTO [User] (username,password,email,registration_date) VALUES (?, ?, ?, ?)",username,password,email,registration_date)
        conn.commit()
        st.success("User details successfully added!")
    except Exception as e:
        st.error(f"Error User Movie: {e}")

def read_user(user_id):
    try:
        cursor.execute("SELECT * FROM [User] WHERE user_id = ?", user_id)
        result = cursor.fetchone()
        if result:
            df = pd.DataFrame([list(result)], columns=['userid','username', 'password', 'email', 'registration_date'
])
            st.table(df)
        else:
            st.warning("User not found.")
    except Exception as e:
        st.error(f"User reading : {e}")

def update_user(user_id,username,password,email,registration_date):
    try:
        cursor.execute("UPDATE [User] SET username = ?, password = ?, email = ?, registration_date = ? WHERE user_id = ?", username,password,email,registration_date,user_id)
        conn.commit()
        st.success("User updated!")
    except Exception as e:
        st.error(f"Error updating User: {e}")

def delete_user(user_id):
    try:
        cursor.execute("DELETE FROM [User] WHERE user_id = ?", user_id)
        conn.commit()
        st.success("User deleted!")
    except Exception as e:
        st.error(f"Error deleting User: {e}")

def read_users():
    try:
        cursor.execute("SELECT * FROM [User]")
        result = cursor.fetchall()
        # print(result)
        if result:
            for row in result:
                df  = pd.DataFrame([list(row)], columns=['userid','username', 'password', 'email', 'registration_date'])
                st.table(df)
        else:
            st.warning("No Movies available")
    except Exception as e:
        st.error(f"Error reading Movie: {e}")


option = st.radio('Select the operation', ["Create", "Read", "Update", "Delete", "Read All"])
if option == "Create":
    username = st.text_input("User Name:")
    password = st.text_input("Password:")
    email = st.text_input("Email ID:")
    registration_date = st.text_input("Registration Date")
    if st.button("Create User"):
        create_user(username, password, email, registration_date)

elif option == "Read":
    user_id = st.number_input("Enter User ID:")
    if st.button("View User"):
        read_user(user_id)

elif option == "Update":
    user_id = st.text_input("User Id:")
    username = st.text_input("User Name:")
    password = st.text_input("Password:")
    email = st.text_input("Email ID:")
    registration_date = st.text_input("Registration Date")
    if st.button("Update User"):
        update_user(user_id,username,password,email,registration_date)

elif option == "Delete":
    user_id = st.number_input("Enter User ID:")
    if st.button("Delete User"):
        delete_user(user_id)

elif option == "Read All":
    if st.button("View Uses"):
        read_users()